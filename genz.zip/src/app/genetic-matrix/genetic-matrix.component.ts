import { Component, OnInit } from '@angular/core';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-genetic-matrix',
  templateUrl: './genetic-matrix.component.html',
  styleUrls: ['./genetic-matrix.component.css']
})
export class GeneticMatrixComponent implements OnInit {

  A: any = { name: 'A', mother: 'nz', father: 'nz' };
  B: any = { name: 'B', mother: 'nz', father: 'nz' };
  C: any = { name: 'C', mother: 'nz', father: 'nz' };
  D: any = { name: 'D', mother: 'nz', father: 'nz' };
  E: any = { name: 'E', mother: 'nz', father: 'nz' };
  F: any = { name: 'F', mother: 'nz', father: 'nz' };

  // motherOfA: any = '0';
  // fatherOfA: any = '0';

  // motherOfB: any = '0';
  // fatherOfB: any = '0';

  // motherOfC: any = '0';
  // fatherOfC: any = '0';

  // motherOfD: any = '0';
  // fatherOfD: any = '0';

  // motherOfE: any = '0';
  // fatherOfE: any = '0';

  // motherOfF: any = '0';
  // fatherOfF: any = '0';

  AA: any = { name: 'AA', value: null }
  AB: any = { name: 'AB', value: null }
  AC: any = { name: 'AC', value: null }
  AD: any = { name: 'AD', value: null }
  AE: any = { name: 'AE', value: null }
  AF: any = { name: 'AF', value: null }

  BA: any = { name: 'BA', value: null }
  BB: any = { name: 'BB', value: null }
  BC: any = { name: 'BC', value: null }
  BD: any = { name: 'BD', value: null }
  BE: any = { name: 'BE', value: null }
  BF: any = { name: 'BF', value: null }

  CA: any = { name: 'CA', value: null }
  CB: any = { name: 'CB', value: null }
  CC: any = { name: 'CC', value: null }
  CD: any = { name: 'CD', value: null }
  CE: any = { name: 'CE', value: null }
  CF: any = { name: 'CF', value: null }

  DA: any = { name: 'DA', value: null }
  DB: any = { name: 'DB', value: null }
  DC: any = { name: 'DC', value: null }
  DD: any = { name: 'DD', value: null }
  DE: any = { name: 'DE', value: null }
  DF: any = { name: 'DF', value: null }

  EA: any = { name: 'EA', value: null }
  EB: any = { name: 'EB', value: null }
  EC: any = { name: 'EC', value: null }
  ED: any = { name: 'ED', value: null }
  EE: any = { name: 'EE', value: null }
  EF: any = { name: 'EF', value: null }

  FA: any = { name: 'FA', value: null }
  FB: any = { name: 'FB', value: null }
  FC: any = { name: 'FC', value: null }
  FD: any = { name: 'FD', value: null }
  FE: any = { name: 'FE', value: null }
  FF: any = { name: 'FF', value: null }


  constructor() { }

  ngOnInit() {
  }

  select(individual, progenitor, sex) {

    if (individual == 'A' && sex == 'mother')
      this.A.mother = progenitor
    if (individual == 'A' && sex == 'father')
      this.A.father = progenitor
    if (individual == 'B' && sex == 'mother')
      this.B.mother = progenitor
    if (individual == 'B' && sex == 'father')
      this.B.father = progenitor
    if (individual == 'C' && sex == 'mother')
      this.C.mother = progenitor
    if (individual == 'C' && sex == 'father')
      this.C.father = progenitor
    if (individual == 'D' && sex == 'mother')
      this.D.mother = progenitor
    if (individual == 'D' && sex == 'father')
      this.D.father = progenitor
    if (individual == 'E' && sex == 'mother')
      this.E.mother = progenitor
    if (individual == 'E' && sex == 'father')
      this.E.father = progenitor
    if (individual == 'F' && sex == 'mother')
      this.F.mother = progenitor
    if (individual == 'F' && sex == 'father')
      this.F.father = progenitor

    if (this.A.mother == this.A.father) {
      this.A.mother = 'nz';
      this.A.father = 'nz';
      var Amother = <HTMLInputElement>document.getElementById('Amother');
      Amother.value = 'nz';
      var Afather = <HTMLInputElement>document.getElementById('Afather');
      Afather.value = 'nz';
    }
    if (this.B.mother == this.B.father) {
      this.B.mother = 'nz';
      this.B.father = 'nz';
      var Bmother = <HTMLInputElement>document.getElementById('Bmother');
      Bmother.value = 'nz';
      var Bfather = <HTMLInputElement>document.getElementById('Bfather');
      Bfather.value = 'nz';
    } if (this.C.mother == this.C.father) {
      this.C.mother = 'nz';
      this.C.father = 'nz';
      var Cmother = <HTMLInputElement>document.getElementById('Cmother');
      Cmother.value = 'nz';
      var Cfather = <HTMLInputElement>document.getElementById('Cfather');
      Cfather.value = 'nz';
    } if (this.D.mother == this.D.father) {
      this.D.mother = 'nz';
      this.D.father = 'nz';
      var Dmother = <HTMLInputElement>document.getElementById('Dmother');
      Dmother.value = 'nz';
      var Dfather = <HTMLInputElement>document.getElementById('Dfather');
      Dfather.value = 'nz';
    } if (this.E.mother == this.E.father) {
      this.E.mother = 'nz';
      this.E.father = 'nz';
      var Emother = <HTMLInputElement>document.getElementById('Emother');
      Emother.value = 'nz';
      var Efather = <HTMLInputElement>document.getElementById('Efather');
      Efather.value = 'nz';
    } if (this.F.mother == this.F.father) {
      this.F.mother = 'nz';
      this.F.father = 'nz';
      var Fmother = <HTMLInputElement>document.getElementById('Fmother');
      Fmother.value = 'nz';
      var Ffather = <HTMLInputElement>document.getElementById('Ffather');
      Ffather.value = 'nz';
    }

  }

  validate() {
    return true;
  }

  resetAllValues() {
    this.AA.value = 0;
    this.AB.value = 0;
    this.AC.value = 0;
    this.AD.value = 0;
    this.AE.value = 0;
    this.AF.value = 0;
    this.BA.value = 0;
    this.BC.value = 0;
    this.BD.value = 0;
    this.BE.value = 0;
    this.BF.value = 0;
    this.CA.value = 0;
    this.CB.value = 0;
    this.CC.value = 0;
    this.CD.value = 0;
    this.CE.value = 0;
    this.CF.value = 0;
    this.DA.value = 0;
    this.DB.value = 0;
    this.DC.value = 0;
    this.DD.value = 0;
    this.DE.value = 0;
    this.DF.value = 0;
    this.EA.value = 0;
    this.EB.value = 0;
    this.EC.value = 0;
    this.ED.value = 0;
    this.EE.value = 0;
    this.EF.value = 0;
    this.FA.value = 0;
    this.FB.value = 0;
    this.FC.value = 0;
    this.FD.value = 0;
    this.FE.value = 0;
    this.FF.value = 0;
  }

  calculate() {

    this.resetAllValues();

    // if (this.A.mother == '0' && this.A.father == '0')
    //   this.AA.value = 1;
    // if (this.B.mother == '0' && this.B.father == '0')
    //   this.BB.value = 1;
    // if (this.C.mother == '0' && this.C.father == '0')
    //   this.CC.value = 1;
    // if (this.D.mother == '0' && this.D.father == '0')
    //   this.DD.value = 1;
    // if (this.E.mother == '0' && this.E.father == '0')
    //   this.EE.value = 1;
    // if (this.F.mother == '0' && this.F.father == '0')
    //   this.FF.value = 1;


    // if (this.BB.value == 1)
    //   this.AB.value = 0;
    // if (this.CC.value == 1) {
    //   this.AC.value = 0;
    //   this.BC.value = 0;
    // }
    // if (this.DD.value == 1) {
    //   this.AD.value = 0;
    //   this.BD.value = 0;
    //   this.CD.value = 0;
    // }
    // if (this.EE.value == 1) {
    //   this.AE.value = 0;
    //   this.BE.value = 0;
    //   this.CE.value = 0;
    //   this.DE.value = 0;
    // }
    // if (this.FF.value == 1) {
    //   this.AF.value = 0;
    //   this.BF.value = 0;
    //   this.CF.value = 0;
    //   this.DF.value = 0;
    //   this.EF.value = 0;
    // }
    // first decide where to start depending on results above this line 
    // (because we omit those that already got a 0 since we assume there's no inbreeding between them)

    // some test lol

    var results = [];

    var individuals = [];
    individuals.push(this.A);
    individuals.push(this.B);
    individuals.push(this.C);
    individuals.push(this.D);
    individuals.push(this.E);
    individuals.push(this.F);

    for (let i = 0; i < individuals.length; i++) {
      const individualI = individuals[i];
      
      for (let j = 0; j < individuals.length; j++) {
        const individualJ = individuals[j];
        
        // if (individualI.mother == '0' && individualI.father == '0')

        console.log(individualI);
        console.log(individualJ);

        var inbreedingCoefficient = 0;


        if (individualI.name == individualJ.name) { // DIAGONAL

        }
        else {

        }



        if (individualI.mother == 'nz' && individualI.father == 'nz') {
          inbreedingCoefficient 
        }

        results.push({
          name: individualI.name + individualJ.name
        });

      }

    }
    


    // aij = 0.5 * (aip + aiq)


    // AA
    // aAA = 0.5 * (a)


    // AD 
    // aDA = 0.5 * (aAA + aAB) => 0.5 * (1 + 0) = 0.5

    // if (this.motherOfD == 'A') {

    // }

    // if (this.D.mother == 'A' && this.D.father == 'B')

    // this.DA.value = 0.5 * (this.AA

    // if ((this.D.mother == 'A' && this.D.father == 'B') || (this.D.mother == 'B' && this.D.father == 'A')) {
    //   this.AD.value = 0.5 * (this.AA.value + this.AB.value);
    //   this.DA.value = 0.5 * (this.AA.value + this.AB.value);
    // }
    // else if ((this.D.mother == 'A' && this.D.father == 'C') || (this.D.mother == 'C' && this.D.father == 'A')) {
    //   this.AD.value = 0.5 * (this.AA.value + this.AC.value);
    //   this.DA.value = 0.5 * (this.AA.value + this.AC.value);
    // }
    // else if ((this.D.mother == 'A' && this.D.father == 'D') || (this.D.mother == 'D' && this.D.father == 'A')) {
    //   this.AD.value = 0.5 * (this.AA.value + this.AD.value);
    //   this.DA.value = 0.5 * (this.AA.value + this.AD.value);
    // }
    // else if ((this.D.mother == 'A' && this.D.father == 'E') || (this.D.mother == 'E' && this.D.father == 'A')) {
    //   this.AD.value = 0.5 * (this.AA.value + this.AE.value);
    //   this.DA.value = 0.5 * (this.AA.value + this.AE.value);
    // }
    // else if ((this.D.mother == 'A' && this.D.father == 'F') || (this.D.mother == 'F' && this.D.father == 'A')) {
    //   this.AD.value = 0.5 * (this.AA.value + this.AF.value);
    //   this.DA.value = 0.5 * (this.AA.value + this.AF.value);
    // }
    // //
    // else if ((this.D.mother == 'B' && this.D.father == 'C') || (this.D.mother == 'C' && this.D.father == 'B')) {
    //   this.AD.value = 0.5 * (this.BB.value + this.BC.value);
    //   this.DA.value = 0.5 * (this.BB.value + this.BC.value);
    // }
    // else if ((this.D.mother == 'B' && this.D.father == 'D') || (this.D.mother == 'D' && this.D.father == 'B')) {
    //   this.AD.value = 0.5 * (this.BB.value + this.BD.value);
    //   this.DA.value = 0.5 * (this.BB.value + this.BD.value);
    // }
    // else if ((this.D.mother == 'B' && this.D.father == 'E') || (this.D.mother == 'E' && this.D.father == 'B')) {
    //   this.AD.value = 0.5 * (this.BB.value + this.BE.value);
    //   this.DA.value = 0.5 * (this.BB.value + this.BE.value);
    // }
    // else if ((this.D.mother == 'B' && this.D.father == 'F') || (this.D.mother == 'F' && this.D.father == 'B')) {
    //   this.AD.value = 0.5 * (this.BB.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.BB.value + this.BF.value);
    // }
    // //
    // else if ((this.D.mother == 'C' && this.D.father == 'D') || (this.D.mother == 'D' && this.D.father == 'C')) {
    //   this.AD.value = 0.5 * (this.CC.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.CC.value + this.BF.value);
    // }
    // else if ((this.D.mother == 'C' && this.D.father == 'E') || (this.D.mother == 'E' && this.D.father == 'C')) {
    //   this.AD.value = 0.5 * (this.CC.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.CC.value + this.BF.value);
    // }
    // else if ((this.D.mother == 'C' && this.D.father == 'F') || (this.D.mother == 'F' && this.D.father == 'C')) {
    //   this.AD.value = 0.5 * (this.CC.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.CC.value + this.BF.value);
    // }
    // //
    // else if ((this.D.mother == 'D' && this.D.father == 'E') || (this.D.mother == 'E' && this.D.father == 'D')) {
    //   this.AD.value = 0.5 * (this.DD.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.DD.value + this.BF.value);
    // }
    // else if ((this.D.mother == 'D' && this.D.father == 'F') || (this.D.mother == 'F' && this.D.father == 'D')) {
    //   this.AD.value = 0.5 * (this.DD.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.DD.value + this.BF.value);
    // }
    // //
    // else if ((this.D.mother == 'E' && this.D.father == 'F') || (this.D.mother == 'F' && this.D.father == 'E')) {
    //   this.AD.value = 0.5 * (this.EE.value + this.BF.value);
    //   this.DA.value = 0.5 * (this.EE.value + this.BF.value);
    // }



  }

  returnInbreedCoBetween(i, j) {
    // aij = 0.5 * (aip + aiq)



    // return 0.5 * (i.)
  }

}
